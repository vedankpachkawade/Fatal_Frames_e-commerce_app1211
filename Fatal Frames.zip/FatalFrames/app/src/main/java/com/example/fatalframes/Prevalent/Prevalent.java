package com.example.fatalframes.Prevalent;

import com.example.fatalframes.Model.Users;

public class Prevalent {
    private static Users currentOnlineUser;

    public static final String userPhoneKey = "UserPhone";
    public static final String UserPasswordKey = "UserPassword";
}
